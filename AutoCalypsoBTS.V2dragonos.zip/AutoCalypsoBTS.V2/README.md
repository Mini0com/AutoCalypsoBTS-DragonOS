# AutoCalypsoBTS.V2
AutoCalypsoBTS.V2 Powered By Mini0com Alrayane :) 📱📞
New version dropped AutoCalypsoBTS.V2 – Now with SMPP, USSD Notifications & SMS DDoS by Mini0com

INFO:
AutoCalypsoBTS.V2 is the latest evolution of the original AutoCalypsoBTS framework, now upgraded with a powerful new feature set tailored for advanced telecom simulations, stress testing, and BTS interaction.

Developed by Mini0com Alrayane, this version adds critical telecom-layer enhancements for deeper penetration testing and automation, including: 
SMPP Spam
USSD Notification Spam
SMS DDOS
Spoof MSISDN
Tshark Catche real-time SMS 

Install :

sudo apt install tshark gnome-terminal featherpad git

git clone https://github.com/Mini0com/AutoCalypsoBTS.V2 && cd AutoCalypsoBTS.V2 && sudo bash install.sh

GUI start :

cd autocalypsobts && sudo python3 autobts.py


❗️ If u use only 1 phone click TRX1 ❗️

❗️ If u use 2 phones click TRX1 then TRX2 + edit Clock setting (add key -2) 

✔️ Correct application launch sequence: TXR1 or TRX1 + TRX2 > Clock > DB > BTS

🟡 Test SMS: Sends Test SMS from number 111 to all subscribers

🟣 Subscribers show: ID, IMSI, MSISDN, IMEI, TMSI, Timestamp, mcc-mnc-type, 

⚙️ - Settings Bash Scripts


Thanks for installing :) Folow me on YouTube @Mini0com

![image alt](https://github.com/Mini0com/AutoCalypsoBTS.V2/blob/c41ec2d85c3632b6e0be9a1140fa27a787a42577/AutoCalypsoBTS.V2/AutoCalypso.V2.png)
![image alt](https://github.com/Mini0com/AutoCalypsoBTS.V2/blob/4bc8fd04560b6a575ca48d9c899cb9c0992e734a/AutoCalypsoBTS.V2/AutoCalypso.V2(2).png)
![image alt](https://github.com/Mini0com/AutoCalypsoBTS.V2/blob/4bc8fd04560b6a575ca48d9c899cb9c0992e734a/AutoCalypsoBTS.V2/AutoCalypso.V2(3).png)
![image alt](https://github.com/Mini0com/AutoCalypsoBTS.V2/blob/94870fdddeb331e3b5011f09d7b15156752ed8f6/AutoCalypsoBTS.V2/AutoCalypso.V2(4).png)
![image alt](https://github.com/Mini0com/AutoCalypsoBTS.V2/blob/4bc8fd04560b6a575ca48d9c899cb9c0992e734a/AutoCalypsoBTS.V2/AutoCalypso.V2(5).png)
