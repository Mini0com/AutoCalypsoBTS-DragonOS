#!/bin/sh

telnet localhost 4242
read e
